import os
import streamlit as st
from typing import List, Optional
from PIL import Image
from paddleocr import PaddleOCR
from pdfminer.high_level import extract_text
import sympy as sp
import faiss
from sentence_transformers import SentenceTransformer
from huggingface_hub import InferenceClient

HF_TOKEN = st.secrets.get("HF_API_TOKEN", None) or os.environ.get("HF_API_TOKEN", None)
if not HF_TOKEN:
    HF_TOKEN = "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"

HF_MODEL_DEFAULT = "mistralai/Mistral-7B-Instruct-v0.3"
EMBED_MODEL_ID = "BAAI/bge-small-en-v1.5"

@st.cache_resource
def get_ocr(): return PaddleOCR(use_angle_cls=True, lang="en")

@st.cache_resource
def get_embedder(): return SentenceTransformer(EMBED_MODEL_ID)

@st.cache_resource
def get_llm(model_id: str): return InferenceClient(model=model_id, token=HF_TOKEN)

def system_prompt(subject: str, mode: str) -> str:
    base = "You are a careful STEM tutor. Provide syllabus-aligned answers."
    if subject == "math": return base + " Solve step by step, then verify final answer."
    if subject == "socio": return base + " Provide contextual answers with key dates."
    return base + " Explain clearly."

def build_user_prompt(subject, mode, question, options, context_chunks):
    lines = []
    if context_chunks:
        lines.append("Use these notes if relevant:")
        for c in context_chunks: lines.append(f"- {c}")
        lines.append("---")
    lines.append(f"Subject: {subject}")
    lines.append(f"Question type: {mode}")
    if options:
        lines.append("Options:")
        for i,opt in enumerate(options): lines.append(f"{chr(65+i)}. {opt}")
    lines.append("Question:")
    lines.append(question.strip())
    return "\n".join(lines)

def call_llm(model_id, system, user):
    client = get_llm(model_id)
    prompt = f"[SYSTEM]\n{system}\n\n[USER]\n{user}\n\n[ASSISTANT]\n"
    return client.text_generation(prompt, max_new_tokens=768, temperature=0.3, top_p=0.9, return_full_text=False)

st.set_page_config(page_title="STEM Bot", layout="wide")
st.title("🔧 STEM Bot (Streamlit + Hugging Face)")

with st.sidebar:
    subject = st.radio("Subject", ["sci","math","socio"], horizontal=True)
    mode = st.radio("Mode", ["mcq","short","long"], horizontal=True, index=1)
    hf_model = st.text_input("HF Model", value=HF_MODEL_DEFAULT)

question = st.text_area("Your question")
opt_a = st.text_input("Option A"); opt_b = st.text_input("Option B")
opt_c = st.text_input("Option C"); opt_d = st.text_input("Option D")
options = [o for o in [opt_a,opt_b,opt_c,opt_d] if o.strip()] or None

up_pdf = st.file_uploader("Upload PDF", type=["pdf"])
up_img = st.file_uploader("Upload Image", type=["png","jpg","jpeg"])
notes = st.text_area("Extra notes")

if st.button("Get Answer", type="primary"):
    context_chunks=[]
    if notes: context_chunks.append(notes[:2000])
    if up_pdf:
        text = extract_text(up_pdf)
        if text: context_chunks.append(text[:2000])
    if up_img:
        image = Image.open(up_img).convert("RGB")
        ocr = get_ocr()
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".png") as tmp:
            image.save(tmp.name)
            res = ocr.ocr(tmp.name, cls=True)
        lines=[]
        for page in res:
            for _,(txt,conf) in page:
                if conf>0.5: lines.append(txt)
        if lines: context_chunks.append("\n".join(lines)[:2000])

    sys = system_prompt(subject,mode)
    user = build_user_prompt(subject,mode,question or "",options,context_chunks)
    with st.spinner("Thinking..."):
        try: raw = call_llm(hf_model,sys,user)
        except Exception as e: raw=f"Error: {e}"

    st.subheader("Answer")
    st.write(raw)
    if subject=="math":
        try:
            last_line = raw.strip().splitlines()[-1]
            sp.sympify(last_line)
        except Exception:
            st.caption("Note: could not auto-verify expression.")
